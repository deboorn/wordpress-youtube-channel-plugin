<?php


class YoutubeChannelPlugin_Controller_Admin extends YoutubeChannelPlugin_Controller_Base
{


}